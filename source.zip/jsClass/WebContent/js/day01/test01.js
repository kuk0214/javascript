var no1 = 10;
console.log(typeof no1);

no1 = 'abcd';

console.log(typeof no1);