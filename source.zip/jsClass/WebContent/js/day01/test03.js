var age = 31;
document.write('<div class="w3-red w3-center" style="font-size: 24pt;">외부 자바스크립트 파일</div>');
document.write('내가 부러운 나이는 ' + age + '입니다.');