console.log('Hello World');

var num = 0;

for(var i = 0 ; i < 10 ; i++ ) {
	num += (i + 1);
}

console.log("num : " + num);
/*
	실행은 ctr1 + F11 키...
	
	참고 ]
		실행할 때 먼저 저장해줘야 합니다.
		자동 저장 안됩니다...!
*/