var http = require('http');
var url = require('url');
/*
	이 서버에 접속하려면
		http://localhost
	로 접속하면 된다.
*/
http.createServer(function(request, response) {
	var pathname = url.parse(request.url).pathname;
	
	if(pathname == '/'){
		console.log('### 누군가 접속 ###');
		response.writeHead(200, {'Content-Type' : 'text/html'});
		response.end('<h1><center>Welcome Node.js 1st Page!!!</center></h1>');
	}
}).listen(80, function() {
		console.log('***** Server Start *****');
});